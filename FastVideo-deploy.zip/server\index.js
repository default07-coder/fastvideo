'use strict';

const express = require('express');
const path = require('path');
const fs = require('fs');

const config = require('./config');
const ytdlp = require('./ytdlp');
const formats = require('./formats');
const platforms = require('./platforms');
const { JobStore, MIME_TYPES } = require('./jobs');

config.ensureDirs();

const app = express();
const store = new JobStore();

app.disable('x-powered-by');
app.use(express.json({ limit: '256kb' }));

// ---------------------------------------------------------------- Middleware

/** حد بسيط لمعدل الطلبات (لكل IP) */
function rateLimit({ windowMs, max, message }) {
  const hits = new Map();
  return (req, res, next) => {
    const key = req.ip || 'unknown';
    const now = Date.now();
    const entry = hits.get(key) || { count: 0, reset: now + windowMs };
    if (now > entry.reset) { entry.count = 0; entry.reset = now + windowMs; }
    entry.count += 1;
    hits.set(key, entry);
    if (entry.count > max) {
      return res.status(429).json({ ok: false, error: message });
    }
    next();
  };
}

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});

// ------------------------------------------------------------------- Pages

app.use(express.static(config.PUBLIC_DIR, { extensions: ['html'], maxAge: '1h' }));

// -------------------------------------------------------------------- API

/** حالة النظام */
app.get('/api/health', async (req, res) => {
  res.json({
    ok: true,
    app: 'FastVideo',
    version: '1.0.0',
    ytdlp: ytdlp.isReady() ? { ready: true, version: ytdlp.version, runner: ytdlp.runner } : { ready: false },
    ffmpeg: config.FFMPEG_PATH ? { ready: true, path: config.FFMPEG_PATH } : { ready: false },
    cookies: fs.existsSync(config.COOKIES_FILE),
    activeJobs: store.jobs.size,
    platforms: platforms.PLATFORMS.map((p) => ({ id: p.id, name: p.name, nameAr: p.nameAr, color: p.color })),
  });
});

/** قائمة المنصات */
app.get('/api/platforms', (req, res) => {
  res.json({ ok: true, platforms: platforms.PLATFORMS });
});

/** فحص الرابط واستخراج المعلومات */
app.post(
  '/api/info',
  rateLimit({ windowMs: 60 * 1000, max: 60, message: 'طلبات كثيرة جدًا، انتظر قليلًا' }),
  async (req, res) => {
    const { url, browser } = req.body || {};
    const check = platforms.validateUrl(url);
    if (!check.ok) return res.status(400).json({ ok: false, error: check.error });

    if (!ytdlp.isReady()) {
      return res.status(503).json({ ok: false, error: 'محرك التحميل غير جاهز — ثبّت yt-dlp بالأمر: pip install -U yt-dlp' });
    }

    try {
      const raw = await fetchInfo(check.url, normalizeBrowser(browser), false);
      const info = formats.analyze(raw, check.platform);
      res.json({ ok: true, info, platform: check.platform });
    } catch (err) {
      res.status(400).json({ ok: false, error: err.message || 'تعذّر جلب الفيديو' });
    }
  }
);

/** بدء عملية تحميل */
app.post(
  '/api/download',
  rateLimit({ windowMs: 60 * 1000, max: 40, message: 'طلبات كثيرة جدًا، انتظر قليلًا' }),
  async (req, res) => {
    const { url, quality = 'hd', browser, mode } = req.body || {};
    const check = platforms.validateUrl(url);
    if (!check.ok) return res.status(400).json({ ok: false, error: check.error });

    if (!ytdlp.isReady()) {
      return res.status(503).json({ ok: false, error: 'محرك التحميل غير جاهز' });
    }

    const kind = mode === 'audio' ? 'audio' : mode === 'playlist' ? 'playlist' : 'video';

    let selector = 'bestvideo+bestaudio/best';
    let title = 'تحميل';
    let thumbnail = null;

    try {
      const raw = await fetchInfo(check.url, normalizeBrowser(browser), kind === 'playlist');
      const info = formats.analyze(raw, check.platform);
      title = info.title;
      thumbnail = info.thumbnail;

      if (kind === 'video') {
        const chosen =
          info.qualities.find((q) => q.id === quality) ||
          info.resolutions.find((r) => r.id === quality) ||
          info.resolutions[0];
        if (!chosen) throw new Error('لا توجد جودة متاحة لهذا الفيديو');
        selector = chosen.selector;
      } else if (kind === 'playlist') {
        selector = 'bestvideo+bestaudio[ext=m4a]/best[height<=1080]';
      }
    } catch (err) {
      return res.status(400).json({ ok: false, error: err.message || 'تعذّر جلب الفيديو' });
    }

    const job = store.create({
      url: check.url,
      quality: kind === 'audio' ? 'mp3' : quality,
      selector,
      mode: kind,
      title,
      thumbnail,
      platform: check.platform.id,
      browser: normalizeBrowser(browser),
    });

    res.json({ ok: true, job: job.snapshot() });
  }
);

/** قائمة المهام */
app.get('/api/jobs', (req, res) => {
  res.json({ ok: true, jobs: store.list() });
});

/** حالة مهمة */
app.get('/api/jobs/:id', (req, res) => {
  const job = store.get(req.params.id);
  if (!job) return res.status(404).json({ ok: false, error: 'المهمة غير موجودة' });
  res.json({ ok: true, job: job.snapshot() });
});

/** بث لحظي للتقدّم (SSE) */
app.get('/api/jobs/:id/stream', (req, res) => {
  const job = store.get(req.params.id);
  if (!job) return res.status(404).json({ ok: false, error: 'المهمة غير موجودة' });

  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });

  const send = () => {
    try {
      res.write(`data: ${JSON.stringify(job.snapshot())}\n\n`);
    } catch (_) { /* ignore */ }
  };

  send();

  const onUpdate = () => {
    send();
    if (['done', 'error', 'canceled'].includes(job.status)) {
      cleanup();
      res.end();
    }
  };

  const heartbeat = setInterval(() => {
    try { res.write(': ping\n\n'); } catch (_) { /* ignore */ }
  }, 15000);

  function cleanup() {
    clearInterval(heartbeat);
    job.removeListener('update', onUpdate);
  }

  job.on('update', onUpdate);
  req.on('close', cleanup);
});

/** إلغاء مهمة */
app.post('/api/jobs/:id/cancel', (req, res) => {
  const job = store.get(req.params.id);
  if (!job) return res.status(404).json({ ok: false, error: 'المهمة غير موجودة' });
  if (['done', 'error', 'canceled'].includes(job.status)) {
    return res.json({ ok: true, job: job.snapshot() });
  }
  job.status = 'canceled';
  job.finishedAt = Date.now();
  if (job.controller) job.controller.abort();
  job.setProgress({ status: 'canceled', stage: 'تم الإلغاء', speed: 0, eta: null });
  job.emit('update');
  res.json({ ok: true, job: job.snapshot() });
});

/** تحميل الملف الناتج */
app.get('/api/jobs/:id/file', (req, res) => {
  const job = store.get(req.params.id);
  if (!job) return res.status(404).json({ ok: false, error: 'المهمة غير موجودة' });
  if (!job.result || !job.result.path || !fs.existsSync(job.result.path)) {
    return res.status(404).json({ ok: false, error: 'الملف غير متاح' });
  }

  const stat = fs.statSync(job.result.path);
  const inline = req.query.inline === '1';
  const mime = job.result.mime || MIME_TYPES[path.extname(job.result.path).toLowerCase()] || 'application/octet-stream';
  const downloadName = job.result.isZip
    ? job.result.name
    : `${sanitizeFilename(job.title)}.${path.extname(job.result.path).replace('.', '') || 'mp4'}`;

  res.setHeader('Content-Type', mime);
  res.setHeader('Content-Length', stat.size);
  res.setHeader(
    'Content-Disposition',
    `${inline ? 'inline' : 'attachment'}; filename="${asciiName(downloadName)}"; filename*=UTF-8''${encodeURIComponent(downloadName)}`
  );
  res.setHeader('Cache-Control', 'private, max-age=3600');

  const stream = fs.createReadStream(job.result.path);
  stream.on('error', () => res.end());
  stream.pipe(res);
});

/** تحميل ملف منفرد من قائمة تشغيل */
app.get('/api/jobs/:id/file/:index', (req, res) => {
  const job = store.get(req.params.id);
  if (!job) return res.status(404).json({ ok: false, error: 'المهمة غير موجودة' });
  const idx = Number(req.params.index);
  const file = job.files[idx];
  if (!file) return res.status(404).json({ ok: false, error: 'الملف غير موجود' });
  const full = path.join(job.dir, file.name);
  if (!fs.existsSync(full)) return res.status(404).json({ ok: false, error: 'الملف غير موجود' });

  const stat = fs.statSync(full);
  res.setHeader('Content-Type', file.mime || 'application/octet-stream');
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(file.name)}`);
  fs.createReadStream(full).pipe(res);
});

/** رفع ملف الكوكيز (نص cookies.txt) */
app.post(
  '/api/cookies',
  express.text({ type: ['text/plain', 'text/html'], limit: '4mb' }),
  (req, res) => {
    const content = String(req.body || '');
    if (!content || content.length < 10) {
      return res.status(400).json({ ok: false, error: 'الملف فارغ أو غير صالح' });
    }
    const hasHeader = /^# Netscape HTTP Cookie File/i.test(content.trim());
    if (!hasHeader && !/netscape/i.test(content.slice(0, 200))) {
      return res.status(400).json({ ok: false, error: 'صيغة cookies.txt غير صحيحة' });
    }
    fs.writeFileSync(config.COOKIES_FILE, content, 'utf8');
    res.json({ ok: true, message: 'تم حفظ الكوكيز بنجاح' });
  }
);

/** حذف الكوكيز */
app.delete('/api/cookies', (req, res) => {
  try {
    if (fs.existsSync(config.COOKIES_FILE)) fs.unlinkSync(config.COOKIES_FILE);
  } catch (_) { /* ignore */ }
  res.json({ ok: true, message: 'تم حذف الكوكيز' });
});

/** حالة الكوكيز */
app.get('/api/cookies', (req, res) => {
  const exists = fs.existsSync(config.COOKIES_FILE);
  res.json({
    ok: true,
    exists,
    size: exists ? fs.statSync(config.COOKIES_FILE).size : 0,
    browsers: config.SUPPORTED_BROWSERS,
  });
});

/** 404 */
app.use('/api', (req, res) => {
  res.status(404).json({ ok: false, error: 'المسار غير موجود' });
});

// --------------------------------------------------------------- Helpers

/** كاش قصير العمر لتفادي جلب نفس الفيديو مرتين */
const infoCache = new Map();
const INFO_CACHE_TTL = 5 * 60 * 1000;

async function fetchInfo(url, browser, playlist) {
  const key = `${url}|${browser || ''}|${playlist ? 'pl' : 'single'}`;
  const cached = infoCache.get(key);
  if (cached && Date.now() - cached.at < INFO_CACHE_TTL) return cached.data;

  const data = await ytdlp.dumpJson(url, {
    cookiesFile: config.COOKIES_FILE,
    browser,
    playlist,
  });

  infoCache.set(key, { at: Date.now(), data });
  if (infoCache.size > 60) {
    const oldest = [...infoCache.entries()].sort((a, b) => a[1].at - b[1].at)[0];
    if (oldest) infoCache.delete(oldest[0]);
  }
  return data;
}

function normalizeBrowser(browser) {
  if (!browser) return null;
  const b = String(browser).toLowerCase();
  return config.SUPPORTED_BROWSERS.includes(b) ? b : null;
}

function sanitizeFilename(name) {
  return String(name || 'video')
    .replace(/[\\/:*?"<>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 90) || 'video';
}

function asciiName(name) {
  return String(name).replace(/[^\x20-\x7E]/g, '_').slice(0, 120) || 'download';
}

// --------------------------------------------------------------- Startup

async function start() {
  const probe = await ytdlp.init();
  if (!probe.ok) {
    console.log(`\n[FastVideo] WARNING: ${probe.error}\n`);
  } else {
    console.log(`[FastVideo] yt-dlp  : ${probe.version}  (${probe.runner})`);
  }
  console.log(`[FastVideo] ffmpeg  : ${config.FFMPEG_PATH || 'NOT FOUND (run: npm run setup)'}`);
  console.log(`[FastVideo] downloads: ${config.DOWNLOADS_DIR}`);
  console.log(`[FastVideo] running on: http://localhost:${config.PORT}\n`);

  setInterval(() => store.cleanup(), 10 * 60 * 1000).unref();

  app.listen(config.PORT, config.HOST, () => {
    console.log(`[FastVideo] READY -> http://localhost:${config.PORT}\n`);
  });
}

if (require.main === module) start();

module.exports = app;
