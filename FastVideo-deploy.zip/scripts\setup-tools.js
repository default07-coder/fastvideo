'use strict';

/**
 * تجهيز الأدوات المطلوبة لتشغيل FastVideo:
 *  1) تثبيت yt-dlp عبر pip
 *  2) تثبيت ffmpeg عبر حزمة npm @ffmpeg-installer/ffmpeg
 *
 * التشغيل: npm run setup
 */

const { spawnSync } = require('child_process');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function run(cmd, args, opts = {}) {
  console.log(`\n▶ ${cmd} ${args.join(' ')}`);
  const res = spawnSync(cmd, args, {
    cwd: ROOT,
    stdio: 'inherit',
    shell: process.platform === 'win32',
    ...opts,
  });
  return res.status === 0;
}

console.log('\n=== تجهيز FastVideo ===\n');

// 1) yt-dlp
const python = process.env.YTDLP_PYTHON || 'python';
if (run(python, ['-m', 'pip', 'install', '--upgrade', 'yt-dlp'])) {
  console.log('✅ تم تثبيت/تحديث yt-dlp');
} else {
  console.log('⚠️  تعذّر تثبيت yt-dlp عبر pip. ثبّته يدويًا: pip install -U yt-dlp');
}

// 2) ffmpeg
if (run('npm', ['install', '@ffmpeg-installer/ffmpeg', '@ffprobe-installer/ffprobe'])) {
  console.log('✅ تم تجهيز ffmpeg');
} else {
  console.log('⚠️  تعذّر تثبيت ffmpeg عبر npm');
}

console.log('\n=== اكتمل — شغّل: npm start ===\n');
