'use strict';

/**
 * FastVideo — النشر المجاني على الإنترنت
 * يشغّل الخادم (إن لم يكن يعمل) ثم يفتح نفقًا عامًا عبر Cloudflare Quick Tunnel
 * بدون حساب وبدون حدّ زمني، ويعطي رابط HTTPS حقيقي.
 *
 * التشغيل:  npm run tunnel
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');

const ROOT = path.resolve(__dirname, '..');
const PORT = Number(process.env.PORT || 3000);
const CF = path.join(ROOT, 'tools', 'cloudflared.exe');
const CF_FALLBACK = path.join(ROOT, 'tools', 'cloudflared');
const URL_FILE = path.join(ROOT, 'data', 'public-url.txt');

const C = {
  reset: '\x1b[0m', dim: '\x1b[2m', bold: '\x1b[1m',
  violet: '\x1b[38;5;141m', cyan: '\x1b[38;5;51m',
  green: '\x1b[38;5;47m', red: '\x1b[38;5;203m', yellow: '\x1b[38;5;221m',
};

function banner(url) {
  const line = '─'.repeat(66);
  console.log(`\n${C.violet}${C.bold}╔${line}╗${C.reset}`);
  console.log(`${C.violet}${C.bold}║${C.reset}  ${C.bold}  FastVideo is now LIVE on the internet${C.reset}`);
  console.log(`${C.violet}${C.bold}║${C.reset}`);
  console.log(`${C.violet}${C.bold}║${C.reset}  ${C.green}${C.bold}${url}${C.reset}`);
  console.log(`${C.violet}${C.bold}║${C.reset}`);
  console.log(`${C.violet}${C.bold}║${C.reset}  ${C.dim}Stop it with Ctrl+C${C.reset}`);
  console.log(`${C.violet}${C.bold}╚${line}╝${C.reset}\n`);
}

function ping(port) {
  return new Promise((resolve) => {
    const req = http.get({ host: '127.0.0.1', port, path: '/api/health', timeout: 2500 }, (res) => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
  });
}

async function waitForServer(port, timeoutMs = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (await ping(port)) return true;
    await new Promise((r) => setTimeout(r, 600));
  }
  return false;
}

function resolveBinary() {
  for (const p of [CF, CF_FALLBACK]) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

(async () => {
  console.log(`${C.dim}[FastVideo] preparing...${C.reset}`);

  // 1) تشغيل الخادم إن لزم
  if (await ping(PORT)) {
    console.log(`${C.green}[OK]${C.reset} server already running on port ${PORT}`);
  } else {
    console.log(`${C.cyan}[*]${C.reset} starting server ...`);
    const server = spawn(process.execPath, [path.join(ROOT, 'server', 'index.js')], {
      cwd: ROOT, detached: false, stdio: ['ignore', 'inherit', 'inherit'],
    });
    server.on('exit', (code) => {
      if (code !== 0 && code !== null) console.error(`${C.red}[X] server stopped (${code})${C.reset}`);
    });
    const ok = await waitForServer(PORT);
    if (!ok) {
      console.error(`${C.red}[X] could not start the server${C.reset}`);
      process.exit(1);
    }
    console.log(`${C.green}[OK]${C.reset} server ready on port ${PORT}`);
  }

  // 2) فتح النفق
  const bin = resolveBinary();
  if (!bin) {
    console.error(`${C.red}[X] cloudflared binary not found${C.reset}`);
    console.error(`  Download: https://github.com/cloudflare/cloudflared/releases/latest`);
    console.error(`  Place it in: ${path.join(ROOT, 'tools')}`);
    process.exit(1);
  }

  console.log(`${C.cyan}[*]${C.reset} opening Cloudflare tunnel ...`);
  const tunnel = spawn(bin, [
    'tunnel', '--no-autoupdate', '--url', `http://localhost:${PORT}`,
  ], { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'] });

  let announced = false;
  const handle = (buf) => {
    const m = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/.exec(buf);
    if (m && !announced) {
      announced = true;
      const url = m[0];
      banner(url);
      try {
        fs.mkdirSync(path.dirname(URL_FILE), { recursive: true });
        fs.writeFileSync(URL_FILE, `${url}\n${new Date().toISOString()}\n`, 'utf8');
      } catch (_) { /* ignore */ }
    }
  };

  tunnel.stdout.on('data', (d) => handle(d.toString()));
  tunnel.stderr.on('data', (d) => handle(d.toString()));

  tunnel.on('exit', (code) => {
    if (code !== 0) {
      console.error(`${C.red}✗ توقف النفق (${code})${C.reset}`);
      process.exit(code || 1);
    }
  });

  const shutdown = () => {
    console.log(`\n${C.yellow}[*] stopping tunnel...${C.reset}`);
    try { tunnel.kill(); } catch (_) { /* ignore */ }
    try { fs.unlinkSync(URL_FILE); } catch (_) { /* ignore */ }
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
})();
