'use strict';

/**
 * تحليل صيغ الفيديو وتحويلها إلى خيارات جودة (HD / متوسط / ضعيف / MP3)
 */

const QUALITY_PRESETS = [
  { id: 'hd', label: 'HD', labelAr: 'جودة عالية', maxHeight: 1080, icon: 'hd' },
  { id: 'medium', label: 'MEDIUM', labelAr: 'جودة متوسطة', maxHeight: 720, icon: 'medium' },
  { id: 'low', label: 'LOW', labelAr: 'جودة منخفضة', maxHeight: 480, icon: 'low' },
];

function num(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function formatSize(bytes) {
  const b = num(bytes);
  if (!b) return null;
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let v = b;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i += 1; }
  return `${v.toFixed(v >= 100 || i === 0 ? 0 : 1)} ${units[i]}`;
}

function isVideoFormat(f) {
  return f && f.vcodec && f.vcodec !== 'none';
}

function isAudioFormat(f) {
  return f && f.acodec && f.acodec !== 'none' && !isVideoFormat(f);
}

function hasAudio(f) {
  return f && f.acodec && f.acodec !== 'none';
}

/**
 * بناء محدّد الصيغة (-f) الآمن لدمج الفيديو مع الصوت
 */
function buildSelector(fmt) {
  if (!fmt) return 'best';
  if (hasAudio(fmt)) return String(fmt.format_id);
  return `${fmt.format_id}+bestaudio[ext=m4a]/bestaudio/best`;
}

/**
 * اختيار أفضل صيغة فيديو ضمن حد أقصى للارتفاع
 */
function pickVideo(formats, maxHeight, fallback = 'best') {
  const videos = formats
    .filter((f) => isVideoFormat(f) && num(f.height) > 0)
    .sort((a, b) => {
      if (num(b.height) !== num(a.height)) return num(b.height) - num(a.height);
      const fr = num(b.fps) - num(a.fps);
      if (fr !== 0) return fr;
      return num(b.tbr) - num(a.tbr);
    });

  if (!videos.length) return null;

  const within = videos.filter((f) => num(f.height) <= maxHeight);
  if (within.length) return within[0];

  if (fallback === 'smallest') return videos[videos.length - 1];
  return videos[0];
}

function pickAudio(formats) {
  const audios = formats
    .filter(isAudioFormat)
    .sort((a, b) => num(b.abr || b.tbr) - num(a.abr || a.tbr));
  if (audios.length) return audios[0];

  // بعض المنصات تعطي الصوت داخل صيغة الفيديو فقط
  const progressive = formats
    .filter((f) => isVideoFormat(f) && hasAudio(f))
    .sort((a, b) => num(b.abr || b.tbr) - num(a.abr || a.tbr));
  return progressive[0] || null;
}

function describeFormat(fmt, audioFmt, label, labelAr, id, duration) {
  const vSize = estimateSize(fmt, duration);
  const aSize = (audioFmt && !hasAudio(fmt)) ? estimateSize(audioFmt, duration) : 0;
  const total = vSize && aSize ? vSize + aSize : vSize || aSize;

  return {
    id,
    label,
    labelAr,
    height: num(fmt.height) || null,
    fps: num(fmt.fps) || null,
    ext: fmt.ext || 'mp4',
    formatId: fmt.format_id,
    selector: buildSelector(fmt),
    hasAudio: hasAudio(fmt),
    size: total || null,
    sizeText: formatSize(total),
    estimated: !num(fmt.filesize) && !num(fmt.filesize_approx),
    note: null,
  };
}

/**
 * تقدير حجم الملف: يستخدم filesize إن وُجد، وإلا يحسبه من معدل البت والمدة.
 */
function estimateSize(fmt, duration) {
  const exact = num(fmt.filesize) || num(fmt.filesize_approx);
  if (exact) return exact;
  const bitrate = num(fmt.tbr) || num(fmt.abr);
  if (bitrate && duration) {
    return Math.round((bitrate * 1000 / 8) * duration);
  }
  return 0;
}

/**
 * تحليل كامل لجSON القادم من yt-dlp
 */
function analyze(json, platformMeta) {
  const isPlaylist = json && json._type === 'playlist';
  const formats = Array.isArray(json.formats) ? json.formats.filter(Boolean) : [];

  const info = {
    title: (json && json.title) || 'بدون عنوان',
    uploader: (json && (json.uploader || json.channel || json.uploader_id)) || 'غير معروف',
    uploaderUrl: (json && json.uploader_url) || null,
    duration: num(json && json.duration) || null,
    thumbnail: (json && json.thumbnail) || null,
    description: (json && json.description) || '',
    extractor: (json && json.extractor_key) || (json && json.extractor) || null,
    platform: platformMeta ? platformMeta.id : 'other',
    platformName: platformMeta ? platformMeta.nameAr : 'موقع آخر',
    platformColor: platformMeta ? platformMeta.color : '#7c5cff',
    isLive: Boolean(json && json.is_live),
    wasLive: Boolean(json && json.was_live),
    isPlaylist,
    playlistCount: 0,
    viewCount: num(json && json.view_count) || null,
    likeCount: num(json && json.like_count) || null,
    originalUrl: (json && json.webpage_url) || null,
    formats: [],
    qualities: [],
    resolutions: [],
    audio: null,
  };

  if (isPlaylist) {
    const entries = Array.isArray(json.entries) ? json.entries.filter(Boolean) : [];
    info.playlistCount = entries.length;
    info.entries = entries.slice(0, 500).map((e) => ({
      id: e.id,
      title: e.title || 'بدون عنوان',
      uploader: e.uploader || info.uploader,
      duration: num(e.duration) || null,
      thumbnail: e.thumbnail || null,
      url: e.webpage_url || e.url || (e.id ? `https://www.youtube.com/watch?v=${e.id}` : null),
    }));
    return info;
  }

  const audioFmt = pickAudio(formats);
  const duration = num(json && json.duration) || 0;

  // --- الخيارات الرئيسية: HD / متوسط / ضعيف ---
  for (const preset of QUALITY_PRESETS) {
    const fmt = pickVideo(formats, preset.maxHeight, preset.id === 'low' ? 'smallest' : 'best');
    if (!fmt) continue;
    const option = describeFormat(fmt, audioFmt, preset.label, preset.labelAr, preset.id, duration);
    option.note = num(fmt.height) > preset.maxHeight
      ? `أعلى جودة متاحة: ${fmt.height}p`
      : null;
    option.icon = preset.icon;
    info.qualities.push(option);
  }

  // --- قائمة الدقة الكاملة (اختيار دقيق) ---
  const seen = new Set();
  const byHeight = formats
    .filter((f) => isVideoFormat(f) && num(f.height) > 0)
    .sort((a, b) => num(b.height) - num(a.height));

  for (const fmt of byHeight) {
    const h = num(fmt.height);
    if (seen.has(h)) continue;
    seen.add(h);
    const option = describeFormat(fmt, audioFmt, `${h}p`, `${h}p`, `h${h}`, duration);
    info.resolutions.push(option);
  }

  // --- خيار الصوت MP3 ---
  if (audioFmt) {
    const size = estimateSize(audioFmt, duration);
    info.audio = {
      id: 'mp3',
      label: 'MP3',
      labelAr: 'صوت MP3',
      formatId: audioFmt.format_id,
      selector: 'bestaudio/best',
      ext: 'mp3',
      bitrate: '320',
      size: size || null,
      sizeText: formatSize(size),
    };
  }

  info.formats = formats.map((f) => ({
    format_id: f.format_id,
    ext: f.ext,
    height: num(f.height) || null,
    fps: num(f.fps) || null,
    vcodec: f.vcodec,
    acodec: f.acodec,
    size: num(f.filesize || f.filesize_approx) || null,
  }));

  return info;
}

module.exports = { analyze, QUALITY_PRESETS, formatSize, buildSelector, estimateSize };
