'use strict';
/**
 * اختبار شامل لجميع ميزات FastVideo
 * التشغيل: node scripts/test-full.js
 */
const BASE = 'http://localhost:3000';
let pass = 0, fail = 0;

const ok = (name, cond, extra = '') => {
  console.log(`${cond ? '✅' : '❌'} ${name}${extra ? ' → ' + extra : ''}`);
  cond ? pass++ : fail++;
};

const post = async (url, body, headers = {}) => {
  const r = await fetch(BASE + url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...headers },
    body: JSON.stringify(body),
  });
  return { status: r.status, data: await r.json() };
};

(async () => {
  console.log('\n=== FastVideo — الاختبار الشامل ===\n');

  // 1) الصحة
  const health = await (await fetch(`${BASE}/api/health`)).json();
  ok('صحة النظام', health.ok && health.ytdlp.ready && health.ffmpeg.ready);
  ok('عدد المنصات', health.platforms.length >= 15, `${health.platforms.length} منصة`);

  // 2) تحليل
  const t0 = Date.now();
  const info = await post('/api/info', { url: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ' });
  ok('تحليل الرابط', info.data.ok, `${Date.now() - t0}ms`);
  ok('عنوان الفيديو', !!info.data.info?.title, info.data.info?.title?.slice(0, 40));
  ok('الجودة HD', info.data.info.qualities.some((q) => q.id === 'hd' && q.height >= 720), info.data.info.qualities.map(q => `${q.id}:${q.height}p`).join(' '));
  ok('الجودة المتوسطة', info.data.info.qualities.some((q) => q.id === 'medium'));
  ok('الجودة المنخفضة', info.data.info.qualities.some((q) => q.id === 'low'));
  ok('خيار MP3', info.data.info.audio?.bitrate === '320');
  ok('تقدير الحجم', info.data.info.qualities.every((q) => q.sizeText && q.sizeText !== '—'),
     info.data.info.qualities.map((q) => `${q.id}:${q.sizeText}`).join(' '));

  // 3) الأمان
  const bad = await post('/api/info', { url: 'http://192.168.1.1/x' });
  ok('حجب الشبكة الداخلية', !bad.data.ok && /أمنية/.test(bad.data.error || ''));
  const bad2 = await post('/api/info', { url: 'javascript:alert(1)' });
  ok('حجب javascript:', !bad2.data.ok);
  const bad3 = await post('/api/info', { url: '' });
  ok('حجب الرابط الفارغ', !bad3.data.ok);

  // 4) تحميل فيديو
  const dl = await post('/api/download', { url: 'https://www.youtube.com/watch?v=jNQXAC9IVRw', quality: 'low' });
  ok('بدء التحميل', dl.data.ok, dl.data.job?.id);
  const jobId = dl.data.job?.id;

  // 5) SSE
  const sse = await fetch(`${BASE}/api/jobs/${jobId}/stream`);
  const reader = sse.body.getReader();
  const dec = new TextDecoder();
  let buf = '', final = null, sawProgress = false;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const parts = buf.split('\n\n'); buf = parts.pop();
    for (const c of parts) {
      const l = c.split('\n').find((x) => x.startsWith('data: '));
      if (!l) continue;
      const j = JSON.parse(l.slice(6));
      if (j.progress?.percent > 0) sawProgress = true;
      if (['done', 'error', 'canceled'].includes(j.status)) { final = j; }
    }
    if (final) break;
  }
  ok('بث SSE للتقدّم', sawProgress);
  ok('اكتمال التحميل', final?.status === 'done', final?.error || '');
  ok('إنتاج ملف', final?.result?.size > 0, `${final?.result?.name} (${final?.result?.sizeText})`);

  // 6) تنزيل الملف
  const fileRes = await fetch(`${BASE}/api/jobs/${jobId}/file`);
  const buf2 = Buffer.from(await fileRes.arrayBuffer());
  ok('تنزيل الملف', fileRes.status === 200 && buf2.length > 10000, `${(buf2.length / 1024).toFixed(0)} KB`);
  ok('ترويسة التنزيل', /attachment/.test(fileRes.headers.get('content-disposition') || ''));

  // 7) MP3
  const mp3 = await post('/api/download', { url: 'https://www.youtube.com/watch?v=jNQXAC9IVRw', mode: 'audio' });
  const mp3Job = mp3.data.job?.id;
  let mp3Final = null;
  const r3 = await fetch(`${BASE}/api/jobs/${mp3Job}/stream`);
  const rd3 = r3.body.getReader(); let b3 = '';
  while (true) {
    const { done, value } = await rd3.read(); if (done) break;
    b3 += dec.decode(value, { stream: true });
    const ps = b3.split('\n\n'); b3 = ps.pop();
    for (const c of ps) {
      const l = c.split('\n').find((x) => x.startsWith('data: '));
      if (!l) continue;
      const j = JSON.parse(l.slice(6));
      if (['done', 'error'].includes(j.status)) mp3Final = j;
    }
    if (mp3Final) break;
  }
  ok('تحويل MP3', mp3Final?.status === 'done' && mp3Final?.result?.mime === 'audio/mpeg',
     `${mp3Final?.result?.name} (${mp3Final?.result?.sizeText})`);

  // 8) الإلغاء
  const cj = await post('/api/download', { url: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', quality: 'hd' });
  const cancel = await post(`/api/jobs/${cj.data.job.id}/cancel`, {});
  ok('إلغاء المهمة', cancel.data.ok && cancel.data.job.status === 'canceled');

  // 9) الكوكيز
  const cookieBody = '# Netscape HTTP Cookie File\n.youtube.com\tTRUE\t/\tTRUE\t0\ttest\tvalue\n';
  const cr = await fetch(`${BASE}/api/cookies`, {
    method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: cookieBody,
  });
  const cd = await cr.json();
  ok('رفع الكوكيز', cd.ok);
  const cg = await (await fetch(`${BASE}/api/cookies`)).json();
  ok('قراءة حالة الكوكيز', cg.exists === true, `${cg.size} bytes`);
  const badCookie = await fetch(`${BASE}/api/cookies`, {
    method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'random text',
  }).then((r) => r.json());
  ok('رفض كوكيز غير صالح', !badCookie.ok);
  await fetch(`${BASE}/api/cookies`, { method: 'DELETE' });

  // 10) قائمة المهام
  const jobs = await (await fetch(`${BASE}/api/jobs`)).json();
  ok('قائمة المهام', jobs.ok && jobs.jobs.length >= 3, `${jobs.jobs?.length} مهمة`);

  // 11) الصفحة الرئيسية
  const page = await fetch(`${BASE}/`);
  const html = await page.text();
  ok('تحميل الصفحة الرئيسية', page.status === 200 && html.includes('FastVideo'));
  ok('دعم RTL', html.includes('dir="rtl"') && html.includes('lang="ar"'));

  console.log(`\n=== النتيجة: ${pass} ناجح / ${fail} فاشل ===\n`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('خطأ:', e); process.exit(1); });
