'use strict';

const path = require('path');
const fs = require('fs');

const ROOT = path.resolve(__dirname, '..');

const DATA_DIR = path.join(ROOT, 'data');
const DOWNLOADS_DIR = path.join(DATA_DIR, 'downloads');
const PUBLIC_DIR = path.join(ROOT, 'public');
const COOKIES_FILE = path.join(DATA_DIR, 'cookies.txt');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';

/** كم عملية تحميل مسموح بها بالتوازي */
const MAX_CONCURRENT_JOBS = Number(process.env.MAX_CONCURRENT_JOBS || 3);

/** عمر ملفات التحميل قبل حذفها تلقائيًا (بالدقائق) */
const FILE_TTL_MINUTES = Number(process.env.FILE_TTL_MINUTES || 120);

/** الحد الأقصى لحجم الملف الواحد (بالميغابايت) */
const MAX_FILE_SIZE_MB = Number(process.env.MAX_FILE_SIZE_MB || 2048);

/** المتصفحات المدعومة لقراءة الكوكيز مباشرة من الجهاز */
const SUPPORTED_BROWSERS = [
  'chrome', 'chromium', 'edge', 'firefox', 'brave', 'opera', 'vivaldi', 'whale',
];

/**
 * إيجاد مسار ffmpeg:
 * 1) متغير البيئة FFMPEG_PATH
 * 2) حزمة @ffmpeg-installer (ثابتة داخل node_modules)
 * 3) ffmpeg الموجود في PATH
 */
function resolveFfmpeg() {
  if (process.env.FFMPEG_PATH && fs.existsSync(process.env.FFMPEG_PATH)) {
    return process.env.FFMPEG_PATH;
  }
  try {
    const pkg = require('@ffmpeg-installer/ffmpeg');
    if (pkg && pkg.path && fs.existsSync(pkg.path)) return pkg.path;
  } catch (_) { /* غير مثبت */ }

  const ext = process.platform === 'win32' ? '.exe' : '';
  const candidates = [
    path.join(ROOT, 'tools', 'ffmpeg', 'bin', `ffmpeg${ext}`),
    path.join(ROOT, 'tools', `ffmpeg${ext}`),
    `/usr/bin/ffmpeg${ext}`,
    `/usr/local/bin/ffmpeg${ext}`,
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  return null;
}

const FFMPEG_PATH = resolveFfmpeg();

/** مجلد ffmpeg ليُضاف إلى PATH حتى يجده yt-dlp */
function ffmpegDir() {
  return FFMPEG_PATH ? path.dirname(FFMPEG_PATH) : null;
}

function ensureDirs() {
  for (const dir of [DATA_DIR, DOWNLOADS_DIR]) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  }
}

module.exports = {
  ROOT,
  DATA_DIR,
  DOWNLOADS_DIR,
  PUBLIC_DIR,
  COOKIES_FILE,
  PORT,
  HOST,
  MAX_CONCURRENT_JOBS,
  FILE_TTL_MINUTES,
  MAX_FILE_SIZE_MB,
  SUPPORTED_BROWSERS,
  FFMPEG_PATH,
  ffmpegDir,
  ensureDirs,
};
