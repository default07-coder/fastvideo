# ⚡ FastVideo

> موقع احترافي لتحميل الفيديوهات والصوت من **يوتيوب، فيسبوك، انستقرام، تيك توك** والمزيد — مع اختيار الجودة: **HD / متوسط / ضعيف** أو استخراج **MP3**.

<div align="center">

![FastVideo](https://img.shields.io/badge/Node.js-24-green) ![yt-dlp](https://img.shields.io/badge/yt--dlp-latest-red) ![License](https://img.shields.io/badge/license-MIT-blue)

</div>

---

## ✨ المميزات

| الميزة | الوصف |
|---|---|
| 🌍 **150+ منصة** | يوتيوب، فيسبوك، انستقرام، تيك توك، X، Vimeo، SoundCloud، Reddit، Dailymotion… |
| 🎞️ **4 مستويات جودة** | HD (حتى 1080p) · متوسط (720p) · ضعيف (480p) · أو دقة مخصصة بالـ dropdown |
| 🎧 **استخراج MP3** | تحويل أي فيديو إلى صوت MP3 بجودة **320kbps** |
| ⚡ **تقدّم لحظي** | نسبة الإنجاز + السرعة + الوقت المتبقي عبر **SSE** |
| 🔒 **خصوصية** | بدون حسابات، بدون تتبع، وحذف تلقائي للملفات بعد ساعتين |
| 🍪 **دعم الكوكيز** | ارفع `cookies.txt` أو اقرأ الكوكيز من متصفحك مباشرةً |
| 📦 **قوائم التشغيل** | حمّل قائمة كاملة واحصل على ملف **ZIP** |
| 🌗 **وضع ليلي/نهاري** | تصميم عربي RTL متجاوب بالكامل |
| 🛡️ **حماية SSRF** | منع الوصول لعناوين الشبكة الداخلية |

---

## 🚀 التشغيل السريع

```bash
# 1) تثبيت الحزم
npm install

# 2) تجهيز yt-dlp + ffmpeg
pip install -U yt-dlp
npm run setup

# 3) التشغيل
npm start
```

ثم افتح: **http://localhost:3000**

> 💡 `npm run setup` يثبّت `ffmpeg` تلقائيًا عبر حزمة `@ffmpeg-installer/ffmpeg`
> (تعمل على ويندوز بدون تثبيت ffmpeg يدوي).

### على ويندوز (نقرة واحدة)

```bat
start.bat
```

---

## 🔧 متغيرات البيئة

| المتغير | الافتراضي | الوصف |
|---|---|---|
| `PORT` | `3000` | منفذ الخادم |
| `HOST` | `0.0.0.0` | عنوان الاستماع |
| `MAX_CONCURRENT_JOBS` | `3` | عدد التحميلات المتوازية |
| `FILE_TTL_MINUTES` | `120` | مدة حذف الملفات تلقائيًا |
| `MAX_FILE_SIZE_MB` | `2048` | أقصى حجم ملف |
| `FFMPEG_PATH` | — | مسار ffmpeg يدوي |
| `YTDLP_PYTHON` | `python` | مفسر بايثون المستخدم |

---

## 🗂️ هيكل المشروع

```
FastVideo/
├── server/
│   ├── index.js       # Express API + ملفات ثابتة
│   ├── ytdlp.js       # غلاف yt-dlp (تشغيل + تحليل مخرجات + أخطاء عربية)
│   ├── formats.js     # تحليل الصيغ → HD / متوسط / ضعيف / MP3
│   ├── jobs.js        # إدارة المهام + SSE + قائمة التشغيل + ZIP
│   ├── platforms.js   # كشف المنصة + التحقق من الرابط + حماية SSRF
│   └── config.js      # الإعدادات والمسارات
├── public/
│   ├── index.html
│   └── assets/
│       ├── css/style.css
│       └── js/app.js
├── scripts/
│   ├── setup-tools.js   # تجهيز yt-dlp + ffmpeg
│   ├── check-tools.js   # فحص جاهزية الأدوات
│   └── test-e2e.js      # اختبار شامل (تحليل → تحميل → تنزيل)
└── data/
    ├── downloads/     # ملفات مؤقتة (تُحذف تلقائيًا)
    └── cookies.txt    # كوكيز اختيارية
```

---

## 🌐 النشر على الإنترنت (مجاني)

### 🥇 الطريقة الأولى — نفق Cloudflare (فوري، بدون حساب)

يعمل FastVideo من جهازك مباشرةً ويمنحك **رابط HTTPS حقيقي مجاني** خلال ثوانٍ:

```bash
npm run tunnel
```

```
╔══════════════════════════════════════════════════════════════════╗
║   ⚡  FastVideo is now LIVE on the internet                      ║
║                                                                  ║
║   https://your-name.trycloudflare.com                            ║
║                                                                  ║
║   Stop it with Ctrl+C                                            ║
╚══════════════════════════════════════════════════════════════════╝
```

- ✅ **بدون تسجيل حساب** ولا بطاقة بنكية
- ✅ رابط HTTPS مجاني حقيقي على الإنترنت
- ⚠️ الرابط **يتغيّر عند كل إعادة تشغيل** (خاصية الأنفاق المجانية)
- ✅ كل شيء يعمل فعليًا: التحليل، التحميل، MP3، التقدّم اللحظي

> إن تغيّر الرابط، الرابط الجديد يُحفظ تلقائيًا في `data/public-url.txt`

---

### 🥈 الطريقة الثانية — استضافة دائمة مجانية (Render / Fly.io)

جميع الملفات الجاهزة للنشر موجودة (`Dockerfile` + `render.yaml`).

**الخطوات:**

1. أنشئ مستودعًا على GitHub وارفع ملفات المشروع:
   ```bash
   git init
   git add .
   git commit -m "FastVideo v1"
   git branch -M main
   git remote add origin https://github.com/<اسمك>/fastvideo.git
   git push -u origin main
   ```

2. ادخل على [dashboard.render.com](https://dashboard.render.com) → **New +** → **Blueprint**
   وابدأ بـ `render.yaml` الموجود بالمستودع (أو اختر **Web Service** ← Environment: **Docker**).

3. انتظر النشر (≈ 3 دقائق) لتحصل على رابط دائم مثل:
   ```
   https://fastvideo.onrender.com
   ```

**ملاحظات على الخطة المجانية:**
| البند | التفاصيل |
|---|---|
| التكلفة | $0 — 750 ساعة شهريًا |
| الخمول | ينام بعد 15 دقيقة خمول، ويصحو تلقائيًا (≈ 50 ثانية) |
| التخزين | مؤقت — مناسب تمامًا لأن الملفات تُحذف بعد ساعتين |
| ffmpeg | مثبّت داخل الصورة عبر `apt-get` |
| yt-dlp | مثبّت داخل بيئة Python افتراضية |

**منصات أخرى مدعومة بنفس Dockerfile:** Fly.io · Railway · Google Cloud Run · AWS ECS · أي VPS

---

### 📋 مقارنة

| | نفق Cloudflare | Render (مجاني) |
|---|---|---|
| الوقت للإطلاق | **ثوانٍ** | ~3 دقائق |
| يحتاج حساب | ❌ لا | ✅ نعم |
| الرابط | يتغيّر كل مرة | **دائم** |
| يحتاج جهازك يعمل | ✅ نعم | ❌ لا |
| التكلفة | مجاني | مجاني |

---

---

## 🔌 واجهة API

| الطريقة | المسار | الوصف |
|---|---|---|
| `GET` | `/api/health` | حالة النظام والمنصات |
| `POST` | `/api/info` | تحليل الرابط → العنوان + الصيغ + الأحجام |
| `POST` | `/api/download` | بدء تحميل (`quality`: `hd`/`medium`/`low`/`h720`/`mp3`) |
| `GET` | `/api/jobs` | قائمة المهام |
| `GET` | `/api/jobs/:id/stream` | بث SSE لتقدّم التحميل |
| `POST` | `/api/jobs/:id/cancel` | إلغاء مهمة |
| `GET` | `/api/jobs/:id/file` | تنزيل الملف الناتج |
| `POST` | `/api/cookies` | رفع `cookies.txt` |
| `DELETE` | `/api/cookies` | حذف الكوكيز |

### مثال

```bash
curl -X POST http://localhost:3000/api/info \
  -H "Content-Type: application/json" \
  -d '{"url":"https://www.youtube.com/watch?v=aqz-KE-bpKQ"}'
```

```json
{
  "ok": true,
  "info": {
    "title": "Big Buck Bunny 60fps 4K",
    "uploader": "Blender",
    "duration": 635,
    "qualities": [
      { "id": "hd",     "height": 1080, "sizeText": "571 MB" },
      { "id": "medium", "height": 720,  "sizeText": "355 MB" },
      { "id": "low",    "height": 480,  "sizeText": "108 MB" }
    ],
    "audio": { "id": "mp3", "bitrate": "320", "sizeText": "9.8 MB" }
  }
}
```

---

## 🍪 حل مشكلة فيديوهات فيسبوك / انستقرام

كثير من المنشورات تتطلب تسجيل دخول. هناك حلّان:

1. **الكوكيز من المتصفح مباشرة** — اختر `Chrome` / `Edge` / `Firefox` من القائمة داخل صفحة التحميل.
2. **رفع ملف `cookies.txt`** — اضغط زر «الكوكيز» بالأعلى واسحب الملف (يُصدَّر من إضافة المتصفح).

> 🔒 لا يتم إرسال الكوكيز لأي جهة خارجية — تُخزَّن محليًا في `data/cookies.txt`.

---

## ⚠️ الاستخدام القانوني

- يُسمح بتحميل المحتوى **للاستخدام الشخصي غير التجاري** فقط.
- **احترم حقوق الملكية الفكرية** وشروط استخدام المنصات الأصلية.
- الموقع مخصص لتعليم **تنزيل المحتوى الذي تملك حقوقه** أو ما يُسمح بتنزيله.
- **لا تستخدمه** لإعادة نشر أو بيع محتوى لا تملك حقوقه.

---

## 🧪 الاختبار

```bash
npm run check                                  # فحص الأدوات
node scripts/test-e2e.js "<url>" <quality>      # اختبار شامل
```

---

## 📄 الترخيص

MIT — استخدمه بحرية وطوره كما تشاء. 🚀
