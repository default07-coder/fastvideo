'use strict';

/**
 * دعم المنصات + كشف المنصة من الرابط
 */

const PLATFORMS = [
  {
    id: 'youtube',
    name: 'YouTube',
    nameAr: 'يوتيوب',
    color: '#ff0033',
    hosts: ['youtube.com', 'youtu.be', 'm.youtube.com', 'music.youtube.com', 'youtube-nocookie.com'],
  },
  {
    id: 'facebook',
    name: 'Facebook',
    nameAr: 'فيسبوك',
    color: '#1877f2',
    hosts: ['facebook.com', 'fb.watch', 'fb.com', 'm.facebook.com', 'web.facebook.com'],
  },
  {
    id: 'instagram',
    name: 'Instagram',
    nameAr: 'انستقرام',
    color: '#e1306c',
    hosts: ['instagram.com', 'instagr.am', 'ddinstagram.com'],
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    nameAr: 'تيك توك',
    color: '#25f4ee',
    hosts: ['tiktok.com', 'vm.tiktok.com', 'vt.tiktok.com'],
  },
  {
    id: 'twitter',
    name: 'X / Twitter',
    nameAr: 'تويتر',
    color: '#1d9bf0',
    hosts: ['twitter.com', 'x.com', 't.co', 'mobile.twitter.com'],
  },
  {
    id: 'vimeo',
    name: 'Vimeo',
    nameAr: 'Vimeo',
    color: '#1ab7ea',
    hosts: ['vimeo.com', 'player.vimeo.com'],
  },
  {
    id: 'soundcloud',
    name: 'SoundCloud',
    nameAr: 'ساوندكلاود',
    color: '#ff5500',
    hosts: ['soundcloud.com', 'snd.sc'],
  },
  {
    id: 'reddit',
    name: 'Reddit',
    nameAr: 'ريديت',
    color: '#ff4500',
    hosts: ['reddit.com', 'redd.it'],
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    nameAr: 'لينكدإن',
    color: '#0a66c2',
    hosts: ['linkedin.com'],
  },
  {
    id: 'pinterest',
    name: 'Pinterest',
    nameAr: 'بنترست',
    color: '#bd081c',
    hosts: ['pinterest.com', 'pin.it'],
  },
  {
    id: 'vk',
    name: 'VK',
    nameAr: 'VK',
    color: '#0077ff',
    hosts: ['vk.com', 'vkvideo.ru'],
  },
  {
    id: 'streamable',
    name: 'Streamable',
    nameAr: 'Streamable',
    color: '#0f90fa',
    hosts: ['streamable.com'],
  },
  {
    id: 'dailymotion',
    name: 'Dailymotion',
    nameAr: 'Dailymotion',
    color: '#0066dc',
    hosts: ['dailymotion.com', 'dai.ly'],
  },
  {
    id: 'bilibili',
    name: 'Bilibili',
    nameAr: 'بيلي بيلي',
    color: '#00a1d6',
    hosts: ['bilibili.com', 'b23.tv'],
  },
  {
    id: 'rumble',
    name: 'Rumble',
    nameAr: 'Rumble',
    color: '#85c742',
    hosts: ['rumble.com'],
  },
  {
    id: 'youtube-music',
    name: 'YouTube Music',
    nameAr: 'يوتيوب ميوزك',
    color: '#ff0000',
    hosts: [],
  },
];

/**
 * استخراج اسم المضيف من الرابط مع التعامل مع روابط بدون بروتوكول
 */
function hostnameOf(rawUrl) {
  let value = String(rawUrl || '').trim();
  if (!value) return '';
  if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
  try {
    return new URL(value).hostname.toLowerCase().replace(/^www\./, '');
  } catch (_) {
    return '';
  }
}

/**
 * كشف المنصة من الرابط
 */
function detectPlatform(rawUrl) {
  const host = hostnameOf(rawUrl);
  if (!host) return null;
  const clean = host.replace(/^www\./, '');

  for (const p of PLATFORMS) {
    if (p.hosts.some((h) => clean === h || clean.endsWith(`.${h}`) || h.endsWith(`.${clean}`))) {
      return p;
    }
  }
  return {
    id: 'other',
    name: clean || 'موقع آخر',
    nameAr: 'موقع آخر',
    color: '#7c5cff',
    hosts: [],
  };
}

/**
 * التحقق من صحة الرابط + الحماية من SSRF (منع الوصول للشبكة الداخلية)
 */
const BLOCKED_HOSTS = new Set([
  'localhost', '127.0.0.1', '0.0.0.0', '::1', 'ip6-localhost',
  'metadata.google.internal', 'metadata',
]);

function isPrivateHost(host) {
  if (!host) return true;
  if (BLOCKED_HOSTS.has(host)) return true;
  if (/^127\./.test(host)) return true;
  if (/^10\./.test(host)) return true;
  if (/^192\.168\./.test(host)) return true;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(host)) return true;
  if (/^169\.254\./.test(host)) return true;
  if (/\.local$/.test(host)) return true;
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) return false; // IP عام
  return false;
}

/**
 * @returns {{ok:true, url:string, host:string, platform:object}|{ok:false, error:string}}
 */
function validateUrl(rawUrl) {
  const raw = String(rawUrl || '').trim();
  if (!raw) return { ok: false, error: 'الرجاء إدخال رابط الفيديو' };
  if (raw.length > 2000) return { ok: false, error: 'الرابط طويل جدًا' };

  let candidate = raw;
  if (!/^https?:\/\//i.test(candidate)) candidate = `https://${candidate}`;

  let parsed;
  try {
    parsed = new URL(candidate);
  } catch (_) {
    return { ok: false, error: 'الرابط غير صالح' };
  }

  if (!/^https?:$/.test(parsed.protocol)) {
    return { ok: false, error: 'يجب أن يبدأ الرابط بـ http أو https' };
  }
  if (!parsed.hostname) return { ok: false, error: 'الرابط غير صالح' };
  if (isPrivateHost(parsed.hostname.toLowerCase())) {
    return { ok: false, error: 'هذا الرابط غير مسموح لأسباب أمنية' };
  }

  return {
    ok: true,
    url: parsed.toString(),
    host: parsed.hostname.toLowerCase(),
    platform: detectPlatform(candidate),
  };
}

module.exports = { PLATFORMS, detectPlatform, validateUrl, hostnameOf };
