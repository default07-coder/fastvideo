'use strict';
/**
 * اختبار شامل: تحليل -> تحميل -> تتبع التقدم -> تنزيل الملف
 * التشغيل: node scripts/test-e2e.js [url] [quality]
 */
const fs = require('fs');
const path = require('path');

const BASE = process.env.BASE || 'http://localhost:3000';
const URL_ = process.argv[2] || 'https://www.youtube.com/watch?v=BaW_jenozKc';
const QUALITY = process.argv[3] || 'low';

const j = async (url, opt) => {
  const r = await fetch(BASE + url, opt);
  const d = await r.json();
  if (!r.ok || d.ok === false) throw new Error(d.error || `HTTP ${r.status}`);
  return d;
};

(async () => {
  console.log('1) تحليل الرابط …');
  const info = await j('/api/info', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url: URL_ }),
  });
  console.log(`   العنوان : ${info.info.title}`);
  console.log(`   الجودة : ${info.info.qualities.map((q) => `${q.id}=${q.height}p(${q.sizeText})`).join(' , ')}`);

  console.log('2) بدء التحميل …');
  const dl = await j('/api/download', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url: URL_, quality: QUALITY }),
  });
  const jobId = dl.job.id;
  console.log(`   معرّف المهمة : ${jobId}`);

  console.log('3) تتبع التقدم عبر SSE …');
  const res = await fetch(`${BASE}/api/jobs/${jobId}/stream`);
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  let lastLine = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const parts = buf.split('\n\n');
    buf = parts.pop();
    for (const chunk of parts) {
      const line = chunk.split('\n').find((l) => l.startsWith('data: '));
      if (!line) continue;
      const job = JSON.parse(line.slice(6));
      const pct = (job.progress.percent || 0).toFixed(0);
      const line2 = `   [${job.status}] ${pct}% | ${job.progress.stage} | سرعة ${job.progress.speed || 0} B/s`;
      if (line2 !== lastLine) { console.log(line2); lastLine = line2; }
      if (['done', 'error', 'canceled'].includes(job.status)) {
        console.log(`   الحالة النهائية : ${job.status} ${job.error || ''}`);
        if (job.status === 'done') {
          console.log(`   الملف : ${job.result.name} (${job.result.sizeText})`);
          console.log('4) تنزيل الملف …');
          const fr = await fetch(`${BASE}/api/jobs/${jobId}/file`);
          const buf2 = Buffer.from(await fr.arrayBuffer());
          const out = path.join(process.cwd(), 'data', 'test-download.mp4');
          fs.writeFileSync(out, buf2);
          console.log(`   ✅ تم حفظ ${out} (${(buf2.length / 1048576).toFixed(2)} MB)`);
          console.log('   التوقيع:', buf2.slice(4, 12).toString('latin1'));
        }
        process.exit(job.status === 'done' ? 0 : 1);
      }
    }
  }
  process.exit(1);
})().catch((e) => { console.error('فشل:', e.message); process.exit(1); });
