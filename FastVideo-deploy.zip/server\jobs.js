'use strict';

const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const crypto = require('crypto');

const config = require('./config');
const ytdlp = require('./ytdlp');

const MIME_TYPES = {
  '.mp4': 'video/mp4',
  '.m4v': 'video/mp4',
  '.webm': 'video/webm',
  '.mkv': 'video/x-matroska',
  '.mov': 'video/quicktime',
  '.mp3': 'audio/mpeg',
  '.m4a': 'audio/mp4',
  '.wav': 'audio/wav',
  '.opus': 'audio/opus',
  '.ogg': 'audio/ogg',
  '.zip': 'application/zip',
};

let jobCounter = 0;

/**
 * مهمة تحميل واحدة
 */
class Job extends EventEmitter {
  constructor(opts) {
    super();
    this.id = opts.id;
    this.url = opts.url;
    this.quality = opts.quality;
    this.selector = opts.selector;
    this.mode = opts.mode || 'video'; // video | audio
    this.title = opts.title || 'تحميل';
    this.thumbnail = opts.thumbnail || null;
    this.platform = opts.platform || 'other';
    this.browser = opts.browser || null;
    this.dir = opts.dir;
    this.createdAt = Date.now();
    this.startedAt = null;
    this.finishedAt = null;

    this.status = 'queued'; // queued | running | done | error | canceled
    this.error = null;
    this.log = [];

    this.progress = {
      status: 'queued',
      percent: 0,
      downloaded: 0,
      total: 0,
      speed: 0,
      eta: null,
      fragment: 0,
      fragments: 0,
      stage: 'في الانتظار…',
    };

    this.files = [];
    this.result = null; // { name, path, size, mime, isZip }
    this.controller = null; // AbortController
  }

  pushLog(line) {
    const clean = String(line).trim();
    if (!clean) return;
    this.log.push(clean);
    if (this.log.length > 400) this.log.splice(0, this.log.length - 400);
    this.emit('update');
  }

  setProgress(patch) {
    this.progress = { ...this.progress, ...patch };
    this.emit('update');
  }

  snapshot() {
    return {
      id: this.id,
      url: this.url,
      title: this.title,
      thumbnail: this.thumbnail,
      platform: this.platform,
      quality: this.quality,
      mode: this.mode,
      status: this.status,
      error: this.error,
      progress: this.progress,
      files: this.files,
      result: this.result,
      createdAt: this.createdAt,
      startedAt: this.startedAt,
      finishedAt: this.finishedAt,
      logs: this.log.slice(-12),
    };
  }
}

/**
 * مخزن المهام مع تحديد عدد التحميلات المتزامنة
 */
class JobStore {
  constructor() {
    this.jobs = new Map();
    this.queue = [];
    this.running = 0;
    this.max = config.MAX_CONCURRENT_JOBS;
  }

  create(opts) {
    jobCounter += 1;
    const id = `fv_${Date.now().toString(36)}_${jobCounter}_${crypto.randomBytes(3).toString('hex')}`;
    const dir = path.join(config.DOWNLOADS_DIR, id);
    fs.mkdirSync(dir, { recursive: true });

    const job = new Job({ ...opts, id, dir });
    this.jobs.set(id, job);
    this.queue.push(job);
    this.pump();
    return job;
  }

  get(id) {
    return this.jobs.get(id) || null;
  }

  list() {
    return Array.from(this.jobs.values())
      .sort((a, b) => b.createdAt - a.createdAt)
      .map((j) => j.snapshot());
  }

  pump() {
    while (this.running < this.max && this.queue.length) {
      const job = this.queue.shift();
      this.running += 1;
      this.execute(job)
        .catch((err) => {
          job.status = 'error';
          job.error = err && err.message ? err.message : 'خطأ غير معروف';
          job.finishedAt = Date.now();
          job.emit('update');
        })
        .finally(() => {
          this.running -= 1;
          this.pump();
        });
    }
  }

  /**
   * تنفيذ التحميل عبر yt-dlp
   */
  async execute(job) {
    job.status = 'running';
    job.startedAt = Date.now();
    job.controller = new AbortController();
    job.setProgress({ status: 'starting', percent: 0, stage: 'جاري التحضير…' });
    job.emit('update');

    const isAudio = job.mode === 'audio';
    const isPlaylist = job.mode === 'playlist';

    const args = [
      '--no-colors',
      '--newline',
      '--no-warnings',
      '--ignore-config',
      '--retries', '10',
      '--fragment-retries', '10',
      '--concurrent-fragments', '4',
      '--socket-timeout', '30',
      '--no-check-certificates',
      '--max-filesize', `${config.MAX_FILE_SIZE_MB}M`,
      '--progress-template', `${ytdlp.PROGRESS_PREFIX} ${ytdlp.PROGRESS_TEMPLATE}`,
    ];

    if (fs.existsSync(config.COOKIES_FILE)) args.push('--cookies', config.COOKIES_FILE);
    if (job.browser) args.push('--cookies-from-browser', job.browser);

    if (isAudio) {
      args.push('-f', 'bestaudio/best', '-x', '--audio-format', 'mp3', '--audio-quality', '320K');
    } else {
      args.push('-f', job.selector || 'bestvideo+bestaudio/best', '--merge-output-format', 'mp4');
    }

    if (isPlaylist) {
      args.push('--yes-playlist');
      args.push('-o', path.join(job.dir, '%(playlist_index)03d - %(title).70s.%(ext)s'));
    } else {
      args.push('--no-playlist');
      args.push('-o', path.join(job.dir, 'download.%(ext)s'));
    }

    args.push(job.url);

    let lastError = '';

    /**
     * ملاحظة: yt-dlp يكتب سجله وتقدّمه على stdout وليس stderr،
     * لذلك نقرأ من القناتين معًا.
     */
    const handleLine = (line) => {
      if (line.startsWith(ytdlp.PROGRESS_PREFIX)) {
        this.handleProgressLine(job, line);
        return;
      }
      const t = line.trim();
      if (!t) return;
      if (!/^\[/.test(t)) lastError = t;
      job.pushLog(t);
    };

    const res = await ytdlp.run(args, {
      signal: job.controller.signal,
      onStdout: handleLine,
      onStderr: handleLine,
    });

    if (job.status === 'canceled') return;

    if (res.code !== 0) {
      job.status = 'error';
      job.error = ytdlp.cleanError(`${res.stderr}\n${lastError}\n${res.stdout.slice(-2000)}`) || 'فشل التحميل';
      job.finishedAt = Date.now();
      job.setProgress({ status: 'error', stage: 'فشل التحميل' });
      job.emit('update');
      return;
    }

    job.setProgress({ status: 'processing', percent: 100, stage: 'جاري تجهيز الملف…' });

    try {
      const files = this.collectFiles(job.dir);
      job.files = files.map((f) => ({
        name: f.name,
        size: f.size,
        sizeText: f.sizeText,
        mime: f.mime,
      }));

      if (isPlaylist) {
        const zip = await this.createZip(job);
        job.result = zip;
      } else {
        if (!files.length) throw new Error('لم يتم إنتاج أي ملف');
        const target = files.find((f) => f.name.startsWith('download.')) || files[0];
        job.result = {
          name: target.name,
          path: target.path,
          size: target.size,
          sizeText: target.sizeText,
          mime: target.mime,
          isZip: false,
        };
        // حذف الملفات الوسيطة
        for (const f of files) {
          if (f.path !== target.path) {
            try { fs.unlinkSync(f.path); } catch (_) { /* ignore */ }
          }
        }
      }

      job.status = 'done';
      job.finishedAt = Date.now();
      job.setProgress({ status: 'finished', percent: 100, stage: 'اكتمل التحميل', speed: 0, eta: null });
      job.emit('update');
    } catch (err) {
      job.status = 'error';
      job.error = err && err.message ? err.message : 'خطأ أثناء تجهيز الملف';
      job.finishedAt = Date.now();
      job.setProgress({ status: 'error', stage: 'خطأ' });
      job.emit('update');
    }
  }

  handleProgressLine(job, line) {
    const payload = line.slice(ytdlp.PROGRESS_PREFIX.length).trim();
    const parts = payload.split('|');
    const [status, downloaded, total, totalEstimate, speed, eta, fragIndex, fragCount, percentStr] = parts;

    const dl = Number(downloaded) || 0;
    const tot = Number(total) || Number(totalEstimate) || 0;
    let percent = 0;
    if (tot > 0) percent = Math.min(100, Math.max(0, (dl / tot) * 100));
    else if (percentStr) {
      const m = /([\d.]+)/.exec(percentStr);
      if (m) percent = Math.min(100, Math.max(0, parseFloat(m[1])));
    }

    const stages = {
      downloading: 'جاري التحميل…',
      finished: 'اكتمل التحميل',
      error: 'خطأ في التحميل',
    };

    job.setProgress({
      status: status || 'downloading',
      percent: Math.round(percent * 10) / 10,
      downloaded: dl,
      total: tot,
      speed: Number(speed) || 0,
      eta: eta && eta !== 'NA' ? Number(eta) : null,
      fragment: Number(fragIndex) || 0,
      fragments: Number(fragCount) || 0,
      stage: stages[status] || 'جاري التحميل…',
    });
  }

  collectFiles(dir) {
    const out = [];
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (_) {
      return out;
    }
    for (const e of entries) {
      if (!e.isFile()) continue;
      const full = path.join(dir, e.name);
      if (/\.(part|ytdl|part-Frag\d+)$/i.test(e.name)) continue;
      let stat;
      try { stat = fs.statSync(full); } catch (_) { continue; }
      const ext = path.extname(e.name).toLowerCase();
      const size = stat.size;
      out.push({
        name: e.name,
        path: full,
        size,
        sizeText: require('./formats').formatSize(size),
        mime: MIME_TYPES[ext] || 'application/octet-stream',
      });
    }
    return out.sort((a, b) => b.size - a.size);
  }

  /**
   * ضغط قائمة تشغيل في ملف ZIP
   */
  async createZip(job) {
    const zipName = `FastVideo_Playlist_${job.id}.zip`;
    const zipPath = path.join(config.DOWNLOADS_DIR, zipName);
    const ok = await this.runZip(job.dir, zipPath);
    if (!ok) {
      return {
        name: zipName,
        path: zipPath,
        size: 0,
        sizeText: '—',
        mime: 'application/zip',
        isZip: false,
        error: 'تعذّر إنشاء ملف ZIP — يمكنك تحميل الملفات منفردة',
      };
    }
    const stat = fs.statSync(zipPath);
    return {
      name: zipName,
      path: zipPath,
      size: stat.size,
      sizeText: require('./formats').formatSize(stat.size),
      mime: 'application/zip',
      isZip: true,
    };
  }

  runZip(dir, zipPath) {
    return new Promise((resolve) => {
      const attempts = [
        { cmd: 'tar', args: ['-a', '-c', '-f', zipPath, '-C', dir, '.'] },
        {
          cmd: 'powershell',
          args: [
            '-NoProfile', '-NonInteractive', '-Command',
            `Compress-Archive -Path '${dir}\\*' -DestinationPath '${zipPath}' -Force`,
          ],
        },
      ];

      const tryNext = (i) => {
        if (i >= attempts.length) return resolve(false);
        const a = attempts[i];
        try {
          const child = spawn(a.cmd, a.args, { windowsHide: true, shell: false });
          child.on('error', () => tryNext(i + 1));
          child.on('close', (code) => {
            if (code === 0) resolve(true);
            else tryNext(i + 1);
          });
        } catch (_) {
          tryNext(i + 1);
        }
      };
      tryNext(0);
    });
  }

  /**
   * حذف الملفات المنتهية صلاحيتها
   */
  cleanup(ttlMinutes = config.FILE_TTL_MINUTES) {
    const cutoff = Date.now() - ttlMinutes * 60 * 1000;
    for (const [id, job] of this.jobs.entries()) {
      const stamp = job.finishedAt || job.createdAt;
      if (stamp < cutoff && job.status !== 'running') {
        this.jobs.delete(id);
        try { fs.rmSync(job.dir, { recursive: true, force: true }); } catch (_) { /* ignore */ }
      }
    }
    // حذف مجلدات قديمة لمهمة لم تعد مسجلة
    try {
      for (const e of fs.readdirSync(config.DOWNLOADS_DIR, { withFileTypes: true })) {
        if (!e.isDirectory()) continue;
        const full = path.join(config.DOWNLOADS_DIR, e.name);
        const stat = fs.statSync(full);
        if (stat.mtimeMs < cutoff) {
          fs.rmSync(full, { recursive: true, force: true });
        }
      }
    } catch (_) { /* ignore */ }
  }
}

module.exports = { JobStore, Job, MIME_TYPES };
