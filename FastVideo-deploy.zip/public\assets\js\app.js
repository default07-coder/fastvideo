/* =========================================================
   FastVideo — Frontend App
   ========================================================= */
(() => {
  'use strict';

  // ------------------------------------------------------------ State
  const state = {
    info: null,
    quality: 'hd',
    mode: 'video',
    jobs: new Map(),
    browser: '',
    theme: localStorage.getItem('fv-theme') || 'dark',
  };

  // ------------------------------------------------------------ Elements
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  const el = {
    body: document.body,
    html: document.documentElement,
    header: $('.site-header'),
    themeToggle: $('#themeToggle'),
    urlInput: $('#urlInput'),
    pasteBtn: $('#pasteBtn'),
    clearBtn: $('#clearBtn'),
    analyzeBtn: $('#analyzeBtn'),
    platformRow: $('#platformRow'),
    infoPanel: $('#infoPanel'),
    infoThumb: $('#infoThumb'),
    infoDuration: $('#infoDuration'),
    infoPlatform: $('#infoPlatform'),
    infoUploader: $('#infoUploader'),
    infoTitle: $('#infoTitle'),
    infoSub: $('#infoSub'),
    qualityGrid: $('#qualityGrid'),
    exactQuality: $('#exactQuality'),
    browserSelect: $('#browserSelect'),
    playlistToggle: $('#playlistToggle'),
    downloadBtn: $('#downloadBtn'),
    jobs: $('#jobs'),
    toasts: $('#toasts'),
    cookiesModal: $('#cookiesModal'),
    cookieDrop: $('#cookieDrop'),
    cookieFile: $('#cookieFile'),
    cookieStatus: $('#cookieStatus'),
    deleteCookies: $('#deleteCookies'),
    openCookies: $('#openCookies'),
    healthStatus: $('#healthStatus'),
    year: $('#year'),
  };

  // ------------------------------------------------------------ Helpers
  const fmtBytes = (b) => {
    if (!b) return '—';
    const u = ['B', 'KB', 'MB', 'GB'];
    let i = 0, v = Number(b);
    while (v >= 1024 && i < u.length - 1) { v /= 1024; i += 1; }
    return `${v.toFixed(v >= 100 || i === 0 ? 0 : 1)} ${u[i]}`;
  };

  const fmtSpeed = (s) => {
    if (!s) return '—';
    return `${fmtBytes(s)}/ث`;
  };

  const fmtEta = (sec) => {
    if (sec === null || sec === undefined || isNaN(sec)) return '—';
    sec = Math.round(sec);
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  const fmtDuration = (sec) => {
    if (!sec) return '';
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
             : `${m}:${String(s).padStart(2, '0')}`;
  };

  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));

  const api = async (url, options = {}) => {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
    let data;
    try { data = await res.json(); } catch (_) { data = { ok: false, error: 'استجابة غير صالحة من الخادم' }; }
    if (!res.ok || data.ok === false) throw new Error(data.error || `خطأ ${res.status}`);
    return data;
  };

  // ------------------------------------------------------------ Toasts
  const ICONS = { ok: '#i-check', err: '#i-x', info: '#i-info' };
  function toast(message, type = 'info', ms = 4200) {
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = `<svg width="18" height="18"><use href="${ICONS[type] || ICONS.info}"/></svg><span>${esc(message)}</span>`;
    el.toasts.appendChild(t);
    setTimeout(() => {
      t.classList.add('out');
      setTimeout(() => t.remove(), 320);
    }, ms);
  }

  // ------------------------------------------------------------ Theme
  function applyTheme() {
    el.html.setAttribute('data-theme', state.theme);
    localStorage.setItem('fv-theme', state.theme);
  }
  el.themeToggle.addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
  });
  applyTheme();

  // ------------------------------------------------------------ Header scroll
  const onScroll = () => el.header.classList.toggle('scrolled', window.scrollY > 12);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // ------------------------------------------------------------ Health
  async function loadHealth() {
    try {
      const res = await fetch('/api/health').then((r) => r.json());
      const ok = res.ytdlp && res.ytdlp.ready;
      el.healthStatus.classList.add(ok ? 'ok' : 'bad');
      el.healthStatus.innerHTML = `<span class="dot"></span> ${ok ? `المحرك جاهز · yt-dlp ${res.ytdlp.version}` : 'محرك التحميل غير جاهز'}`;
      if (!ok) toast('محرك التحميل غير جاهز — ثبّت yt-dlp: pip install -U yt-dlp', 'err', 8000);
      if (res.platforms) renderPlatforms(res.platforms);
    } catch (_) {
      el.healthStatus.classList.add('bad');
      el.healthStatus.innerHTML = '<span class="dot"></span> تعذّر الاتصال بالخادم';
    }
  }

  // ------------------------------------------------------------ Platforms chips
  const ICON_MAP = {
    youtube: '#i-youtube', facebook: '#i-facebook', instagram: '#i-instagram',
    tiktok: '#i-tiktok', twitter: '#i-twitter', vimeo: '#i-vimeo',
    soundcloud: '#i-soundcloud', reddit: '#i-reddit',
  };
  const SHOW_PLATFORMS = ['youtube', 'facebook', 'instagram', 'tiktok', 'twitter', 'vimeo', 'soundcloud'];

  function renderPlatforms(list) {
    el.platformRow.innerHTML = list
      .filter((p) => SHOW_PLATFORMS.includes(p.id))
      .map((p) => `<span class="chip"><svg width="17" height="17"><use href="${ICON_MAP[p.id] || '#i-globe'}"/></svg>${esc(p.nameAr)}</span>`)
      .join('');
  }

  // ------------------------------------------------------------ Input helpers
  el.urlInput.addEventListener('input', () => {
    el.clearBtn.hidden = !el.urlInput.value;
  });

  el.clearBtn.addEventListener('click', () => {
    el.urlInput.value = '';
    el.clearBtn.hidden = true;
    el.urlInput.focus();
  });

  el.pasteBtn.addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        el.urlInput.value = text.trim();
        el.clearBtn.hidden = false;
        toast('تم لصق الرابط من الحافظة', 'ok', 2200);
        el.analyzeBtn.focus();
      } else {
        toast('الحافظة فارغة', 'info', 2200);
      }
    } catch (_) {
      toast('تعذّر الوصول إلى الحافظة — الصق الرابط يدويًا', 'err');
      el.urlInput.focus();
    }
  });

  el.urlInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); analyze(); }
  });

  el.analyzeBtn.addEventListener('click', analyze);
  el.downloadBtn.addEventListener('click', startDownload);
  el.exactQuality.addEventListener('change', () => {
    if (el.exactQuality.value) {
      state.quality = el.exactQuality.value;
      state.mode = 'video';
      renderQualitySelection();
    }
  });

  el.browserSelect.addEventListener('change', () => { state.browser = el.browserSelect.value; });
  el.playlistToggle.addEventListener('change', () => {
    state.mode = el.playlistToggle.checked ? 'playlist' : 'video';
    el.qualityGrid.querySelectorAll('.q-card').forEach((c) => {
      c.classList.toggle('active', !el.playlistToggle.checked && c.dataset.qid === state.quality);
    });
    updateDownloadLabel();
  });

  // ------------------------------------------------------------ Analyze
  async function analyze() {
    const url = el.urlInput.value.trim();
    if (!url) { toast('أدخل رابط الفيديو أولًا', 'err'); el.urlInput.focus(); return; }

    setBusy(el.analyzeBtn, true, 'جاري التحليل…');
    try {
      const data = await api('/api/info', {
        method: 'POST',
        body: JSON.stringify({ url, browser: state.browser }),
      });

      state.info = data.info;
      state.quality = data.info.qualities.length ? data.info.qualities[0].id : 'hd';
      state.mode = data.info.isPlaylist ? 'playlist' : 'video';
      el.playlistToggle.checked = state.mode === 'playlist';

      renderInfo(data.info);
      el.infoPanel.hidden = false;
      el.infoPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      toast('تم تحليل الرابط بنجاح ✅', 'ok');
    } catch (err) {
      el.infoPanel.hidden = true;
      toast(err.message, 'err', 6500);
    } finally {
      setBusy(el.analyzeBtn, false);
    }
  }

  function setBusy(btn, busy, label) {
    if (busy) {
      btn.dataset.orig = btn.innerHTML;
      btn.innerHTML = `<span class="spinner"></span><span>${esc(label || 'جاري العمل…')}</span>`;
      btn.disabled = true;
    } else {
      if (btn.dataset.orig) btn.innerHTML = btn.dataset.orig;
      btn.disabled = false;
    }
  }

  // ------------------------------------------------------------ Render info
  function renderInfo(info) {
    if (info.thumbnail) {
      el.infoThumb.src = info.thumbnail;
      el.infoThumb.alt = info.title;
      el.infoThumb.onerror = () => { el.infoThumb.style.visibility = 'hidden'; };
    } else {
      el.infoThumb.style.visibility = 'hidden';
    }

    el.infoDuration.textContent = fmtDuration(info.duration) || '';
    el.infoPlatform.textContent = info.platformName || 'فيديو';
    el.infoUploader.textContent = info.uploader || '—';
    el.infoTitle.textContent = info.title || 'بدون عنوان';

    const bits = [];
    if (info.extractor) bits.push(info.extractor);
    if (info.viewCount) bits.push(`${formatCount(info.viewCount)} مشاهدة`);
    if (info.duration) bits.push(fmtDuration(info.duration));
    if (info.isLive) bits.push('بث مباشر');
    if (info.playlistCount) bits.push(`${info.playlistCount} فيديو في القائمة`);
    el.infoSub.textContent = bits.join(' • ');

    // ---- Quality cards ----
    const cards = [];
    for (const q of info.qualities) {
      cards.push(`
        <button type="button" class="q-card" data-qid="${esc(q.id)}" data-selector="${esc(q.selector)}">
          <div class="q-top">
            <span class="q-badge">${esc(q.label)}</span>
            <span class="q-name">${esc(q.labelAr)}</span>
          </div>
          <div class="q-desc">${q.height ? esc(q.height + 'p') + ' • ' : ''}${esc(q.ext.toUpperCase())}${q.fps && q.fps >= 50 ? ' • ' + q.fps + 'fps' : ''}</div>
          <div class="q-size">${q.sizeText ? '≈ ' + esc(q.sizeText) : 'الحجم غير معروف'}${q.note ? ' • ' + esc(q.note) : ''}</div>
        </button>`);
    }
    if (info.audio) {
      cards.push(`
        <button type="button" class="q-card" data-qid="mp3" data-selector="${esc(info.audio.selector)}">
          <div class="q-top">
            <span class="q-badge" style="background:linear-gradient(135deg,#f59e0b,#ef4444)">MP3</span>
            <span class="q-name">صوت فقط</span>
          </div>
          <div class="q-desc">أفضل جودة صوت • ${esc(info.audio.bitrate)}kbps</div>
          <div class="q-size">${info.audio.sizeText ? '≈ ' + esc(info.audio.sizeText) : '—'}</div>
        </button>`);
    }
    el.qualityGrid.innerHTML = cards.join('') || '<p class="q-desc">لا توجد صيغ متاحة</p>';

    el.qualityGrid.querySelectorAll('.q-card').forEach((card) => {
      card.addEventListener('click', () => {
        state.quality = card.dataset.qid;
        state.mode = card.dataset.qid === 'mp3' ? 'audio' : 'video';
        el.playlistToggle.checked = state.mode === 'playlist';
        el.exactQuality.value = '';
        renderQualitySelection();
        updateDownloadLabel();
      });
    });

    // ---- Exact quality select ----
    const opts = ['<option value="">— دقة مخصصة —</option>'];
    for (const r of info.resolutions) {
      opts.push(`<option value="${esc(r.id)}">${esc(r.height + 'p')}${r.sizeText ? ' — ≈ ' + esc(r.sizeText) : ''}</option>`);
    }
    el.exactQuality.innerHTML = opts.join('');
    el.exactQuality.value = '';

    renderQualitySelection();
    updateDownloadLabel();
  }

  function renderQualitySelection() {
    el.qualityGrid.querySelectorAll('.q-card').forEach((c) => {
      c.classList.toggle('active', c.dataset.qid === state.quality && state.mode !== 'playlist');
    });
  }

  function updateDownloadLabel() {
    const span = el.downloadBtn.querySelector('span');
    if (state.mode === 'playlist') span.textContent = 'تحميل قائمة التشغيل';
    else if (state.mode === 'audio') span.textContent = 'تحميل MP3';
    else span.textContent = 'ابدأ التحميل';
  }

  function formatCount(n) {
    if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return String(n);
  }

  // ------------------------------------------------------------ Download
  async function startDownload() {
    if (!state.info) { toast('حلّل الرابط أولًا', 'err'); return; }
    const url = el.urlInput.value.trim();
    if (!url) { toast('الرابط مفقود', 'err'); return; }

    setBusy(el.downloadBtn, true, 'جاري البدء…');
    try {
      const data = await api('/api/download', {
        method: 'POST',
        body: JSON.stringify({
          url,
          quality: state.quality,
          mode: state.mode === 'playlist' ? 'playlist' : (state.quality === 'mp3' ? 'audio' : 'video'),
          browser: state.browser,
        }),
      });
      addJob(data.job);
      toast('بدأ التحميل ✅', 'ok');
      subscribe(data.job.id);
    } catch (err) {
      toast(err.message, 'err', 6500);
    } finally {
      setBusy(el.downloadBtn, false);
      updateDownloadLabel();
    }
  }

  // ------------------------------------------------------------ Jobs
  function addJob(job) {
    state.jobs.set(job.id, job);
    renderJob(job);
  }

  function renderJob(job) {
    let card = document.getElementById(`job-${job.id}`);
    if (!card) {
      card = document.createElement('div');
      card.className = 'job-card';
      card.id = `job-${job.id}`;
      el.jobs.prepend(card);
    }

    const qLabel = job.mode === 'audio' ? 'MP3' : job.mode === 'playlist' ? 'قائمة تشغيل' : (job.quality || '').toUpperCase();
    const p = job.progress || {};

    card.innerHTML = `
      <div class="job-head">
        ${job.thumbnail ? `<img class="job-thumb" src="${esc(job.thumbnail)}" alt="" onerror="this.style.display='none'">` : ''}
        <div style="min-width:0;flex:1">
          <div class="job-title">${esc(job.title || 'تحميل')}</div>
          <div class="job-meta">
            <span class="status ${esc(job.status)}"><span class="dot"></span>${statusText(job.status)}</span>
            <span>${esc(qLabel)}</span>
            ${job.result && job.result.sizeText ? `<span>${esc(job.result.sizeText)}</span>` : ''}
          </div>
        </div>
        <div class="job-actions">
          ${job.status === 'done' ? `<a class="btn btn-primary btn-sm" href="/api/jobs/${esc(job.id)}/file"><svg width="15" height="15"><use href="#i-download"/></svg> حفظ</a>` : ''}
          ${['queued', 'running'].includes(job.status) ? `<button class="btn btn-danger btn-sm" data-cancel="${esc(job.id)}">إلغاء</button>` : ''}
        </div>
      </div>

      ${['queued', 'running'].includes(job.status) ? `
        <div class="progress-track"><div class="progress-bar" style="width:${Math.min(100, p.percent || 0)}%"></div></div>
        <div class="progress-stats">
          <span>الإنجاز <b>${(p.percent || 0).toFixed(0)}%</b></span>
          <span>السرعة <b>${esc(fmtSpeed(p.speed))}</b></span>
          <span>المتبقي <b>${esc(fmtEta(p.eta))}</b></span>
          <span>${esc(p.stage || '')}</span>
        </div>` : ''}

      ${job.status === 'done' && job.result ? `
        <div class="progress-stats" style="margin-top:10px">
          <span>✅ اكتمل — ${esc(job.result.name)}</span>
          <span>${esc(job.result.sizeText || '')}</span>
        </div>` : ''}

      ${job.status === 'error' ? `<div class="job-error">${esc(job.error || 'حدث خطأ')}</div>` : ''}
    `;

    const cancelBtn = card.querySelector('[data-cancel]');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', async () => {
        cancelBtn.disabled = true;
        try {
          const data = await api(`/api/jobs/${cancelBtn.dataset.cancel}/cancel`, { method: 'POST', body: '{}' });
          state.jobs.set(data.job.id, data.job);
          renderJob(data.job);
        } catch (err) { toast(err.message, 'err'); }
      });
    }
  }

  function statusText(s) {
    return { queued: 'في الانتظار', running: 'جارٍ التحميل', done: 'مكتمل', error: 'فشل', canceled: 'ملغى' }[s] || s;
  }

  // ------------------------------------------------------------ SSE
  const streams = new Map();
  function subscribe(jobId) {
    if (streams.has(jobId)) return;
    const es = new EventSource(`/api/jobs/${jobId}/stream`);
    streams.set(jobId, es);

    es.onmessage = (ev) => {
      try {
        const job = JSON.parse(ev.data);
        state.jobs.set(job.id, job);
        renderJob(job);
        if (['done', 'error', 'canceled'].includes(job.status)) {
          es.close();
          streams.delete(jobId);
          if (job.status === 'done') toast('اكتمل التحميل — اضغط «حفظ» لتنزيل الملف', 'ok', 6000);
          else if (job.status === 'error') toast(job.error || 'فشل التحميل', 'err', 7000);
        }
      } catch (_) { /* ignore */ }
    };

    es.onerror = () => {
      es.close();
      streams.delete(jobId);
      pollOnce(jobId);
    };
  }

  async function pollOnce(jobId) {
    try {
      const data = await api(`/api/jobs/${jobId}`);
      state.jobs.set(jobId, data.job);
      renderJob(data.job);
      if (['queued', 'running'].includes(data.job.status)) {
        setTimeout(() => pollOnce(jobId), 2000);
      }
    } catch (_) { /* ignore */ }
  }

  // ------------------------------------------------------------ Cookies modal
  const openModal = () => { el.cookiesModal.hidden = false; document.body.style.overflow = 'hidden'; };
  const closeModal = () => { el.cookiesModal.hidden = true; document.body.style.overflow = ''; };

  el.openCookies.addEventListener('click', async () => {
    openModal();
    el.cookieStatus.className = 'modal-status';
    el.cookieStatus.textContent = '';
    try {
      const res = await fetch('/api/cookies').then((r) => r.json());
      if (res.exists) {
        el.cookieStatus.className = 'modal-status ok';
        el.cookieStatus.textContent = `✅ يوجد ملف كوكيز محفوظ (${fmtBytes(res.size)})`;
      }
    } catch (_) { /* ignore */ }
  });

  el.cookiesModal.addEventListener('click', (e) => {
    if (e.target.hasAttribute('data-close')) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !el.cookiesModal.hidden) closeModal();
  });

  el.cookieDrop.addEventListener('click', () => el.cookieFile.click());
  el.cookieFile.addEventListener('change', () => {
    if (el.cookieFile.files[0]) uploadCookies(el.cookieFile.files[0]);
  });
  ['dragenter', 'dragover'].forEach((ev) =>
    el.cookieDrop.addEventListener(ev, (e) => { e.preventDefault(); el.cookieDrop.classList.add('dragover'); }));
  ['dragleave', 'drop'].forEach((ev) =>
    el.cookieDrop.addEventListener(ev, (e) => { e.preventDefault(); el.cookieDrop.classList.remove('dragover'); }));
  el.cookieDrop.addEventListener('drop', (e) => {
    const f = e.dataTransfer.files[0];
    if (f) uploadCookies(f);
  });

  async function uploadCookies(file) {
    el.cookieStatus.className = 'modal-status';
    el.cookieStatus.textContent = 'جاري الرفع…';
    try {
      const text = await file.text();
      const res = await fetch('/api/cookies', {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain' },
        body: text,
      }).then((r) => r.json());
      if (res.ok) {
        el.cookieStatus.className = 'modal-status ok';
        el.cookieStatus.textContent = '✅ ' + (res.message || 'تم حفظ الكوكيز');
        toast('تم حفظ الكوكيز بنجاح', 'ok');
      } else {
        el.cookieStatus.className = 'modal-status bad';
        el.cookieStatus.textContent = '❌ ' + res.error;
      }
    } catch (err) {
      el.cookieStatus.className = 'modal-status bad';
      el.cookieStatus.textContent = '❌ ' + err.message;
    }
  }

  el.deleteCookies.addEventListener('click', async () => {
    try {
      await fetch('/api/cookies', { method: 'DELETE' });
      el.cookieStatus.className = 'modal-status ok';
      el.cookieStatus.textContent = '✅ تم حذف الكوكيز';
    } catch (_) { /* ignore */ }
  });

  // ------------------------------------------------------------ Stats counters
  function animateCounters() {
    $$('[data-count]').forEach((node) => {
      const target = Number(node.dataset.count);
      const isZero = target === 0;
      if (isZero) { node.textContent = '∞'; return; }
      let cur = 0;
      const step = Math.max(1, Math.ceil(target / 42));
      const timer = setInterval(() => {
        cur += step;
        if (cur >= target) { cur = target; clearInterval(timer); }
        node.textContent = cur;
      }, 28);
    });
  }

  // ------------------------------------------------------------ Init
  el.year.textContent = new Date().getFullYear();
  loadHealth();
  animateCounters();

  // استعادة آخر رابط
  const last = localStorage.getItem('fv-last-url');
  if (last) { el.urlInput.value = last; el.clearBtn.hidden = false; }

  el.urlInput.addEventListener('change', () => {
    if (el.urlInput.value.trim()) localStorage.setItem('fv-last-url', el.urlInput.value.trim());
  });
})();
