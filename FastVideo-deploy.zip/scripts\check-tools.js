'use strict';

/**
 * فحص جاهزية الأدوات: yt-dlp و ffmpeg
 * التشغيل: npm run check
 */

const ytdlp = require('../server/ytdlp');
const config = require('../server/config');

(async () => {
  console.log('\n=== FastVideo — فحص الأدوات ===\n');

  const probe = await ytdlp.init();
  if (probe.ok) {
    console.log(`✅ yt-dlp : ${probe.version}  (${probe.runner})`);
  } else {
    console.log(`❌ yt-dlp : ${probe.error}`);
    console.log('   الحل : pip install -U yt-dlp');
  }

  if (config.FFMPEG_PATH) {
    console.log(`✅ ffmpeg : ${config.FFMPEG_PATH}`);
  } else {
    console.log('❌ ffmpeg : غير موجود');
    console.log('   الحل : npm install @ffmpeg-installer/ffmpeg');
  }

  console.log(`\n📁 مجلد التحميلات : ${config.DOWNLOADS_DIR}`);
  console.log(`🌐 المنفذ          : ${config.PORT}`);
  console.log(`👥 تحميلات متوازية : ${config.MAX_CONCURRENT_JOBS}`);
  console.log(`🧹 حذف الملفات بعد: ${config.FILE_TTL_MINUTES} دقيقة\n`);

  process.exit(probe.ok && config.FFMPEG_PATH ? 0 : 1);
})();
