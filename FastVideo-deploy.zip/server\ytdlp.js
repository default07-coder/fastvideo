'use strict';

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const config = require('./config');

/**
 * غلاف بسيط حول yt-dlp (عبر python -m yt_dlp) مع دعم البث اللحظي للتقدّم.
 */

let RUNNER = null; // { cmd, baseArgs, label }
let VERSION = null;

/** بادئة مخصّصة لقراءة تقدّم التحميل من مخرجات yt-dlp */
const PROGRESS_PREFIX = 'FVPROGRESS';

const PROGRESS_TEMPLATE = [
  `%(progress.status)s`,
  `%(progress.downloaded_bytes)s`,
  `%(progress.total_bytes)s`,
  `%(progress.total_bytes_estimate)s`,
  `%(progress.speed)s`,
  `%(progress.eta)s`,
  `%(progress.fragment_index)s`,
  `%(progress.fragment_count)s`,
  `%(progress._percent_str)s`,
].join('|');

/**
 * تهيئة أمر yt-dlp: يفضّل python -m yt_dlp ثم الملف التنفيذي المباشر.
 */
async function init() {
  const candidates = [
    { cmd: process.env.YTDLP_PYTHON || 'python', baseArgs: ['-m', 'yt_dlp'], label: 'python -m yt_dlp' },
    { cmd: 'python3', baseArgs: ['-m', 'yt_dlp'], label: 'python3 -m yt_dlp' },
    { cmd: 'yt-dlp', baseArgs: [], label: 'yt-dlp' },
    { cmd: 'yt_dlp', baseArgs: [], label: 'yt_dlp' },
  ];

  for (const c of candidates) {
    try {
      const res = await rawSpawn(c.cmd, [...c.baseArgs, '--version'], { timeout: 30000 });
      if (res.code === 0 && res.stdout.trim()) {
        RUNNER = c;
        VERSION = res.stdout.trim().split(/\r?\n/)[0];
        return { ok: true, runner: c.label, version: VERSION };
      }
    } catch (_) { /* جرّب التالي */ }
  }
  return { ok: false, error: 'لم يتم العثور على yt-dlp. ثبّته بالأمر: pip install -U yt-dlp' };
}

function isReady() {
  return Boolean(RUNNER);
}

/**
 * تشغيل أمر مع بيئة جاهزة (PATH يشمل مجلد ffmpeg)
 */
function rawSpawn(cmd, args, { timeout = 0, cwd, env } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, {
      cwd,
      windowsHide: true,
      env: env || buildEnv(),
    });

    let stdout = '';
    let stderr = '';
    let timer = null;

    if (timeout > 0) {
      timer = setTimeout(() => {
        child.kill();
        reject(new Error(`انتهت المهلة بعد ${timeout}ms`));
      }, timeout);
    }

    child.stdout.on('data', (d) => { stdout += d.toString(); });
    child.stderr.on('data', (d) => { stderr += d.toString(); });

    child.on('error', (err) => {
      if (timer) clearTimeout(timer);
      reject(err);
    });

    child.on('close', (code) => {
      if (timer) clearTimeout(timer);
      resolve({ code: code === null ? -1 : code, stdout, stderr });
    });
  });
}

/**
 * بيئة التشغيل مع إضافة ffmpeg إلى PATH
 * ملاحظة: على ويندوز قد يكون المفتاح "Path" بدلًا من "PATH" — نوحّدها لتفادي
 * فقدان مسار النظام داخل العملية المُشغَّلة.
 */
function buildEnv() {
  const env = { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUNBUFFERED: '1' };
  const dir = config.ffmpegDir();

  const pathKeys = Object.keys(env).filter((k) => k.toLowerCase() === 'path');
  const current = pathKeys.length ? env[pathKeys[0]] || '' : '';
  pathKeys.forEach((k) => { delete env[k]; });

  if (dir) {
    env.PATH = `${dir}${path.delimiter}${current}${path.delimiter}${dir}`;
    env.FFMPEG_LOCATION = config.FFMPEG_PATH;
  } else {
    env.PATH = current;
  }
  return env;
}

/**
 * تشغيل yt-dlp مع التقاط المخرجات سطرًا بسطر.
 * @param {string[]} args
 * @param {{onStdout?:Function, onStderr?:Function, cwd?:string, signal?:AbortSignal, timeout?:number}} opts
 */
function run(args, opts = {}) {
  return new Promise((resolve, reject) => {
    if (!RUNNER) return reject(new Error('yt-dlp غير مهيأ'));

    const child = spawn(RUNNER.cmd, [...RUNNER.baseArgs, ...args], {
      cwd: opts.cwd,
      windowsHide: true,
      env: buildEnv(),
    });

    const stdoutChunks = [];
    let stderrAll = '';
    let stderrBuffer = '';
    let stdoutBuffer = '';

    const onAbort = () => { try { child.kill(); } catch (_) { /* ignore */ } };
    if (opts.signal) {
      if (opts.signal.aborted) return onAbort();
      opts.signal.addEventListener('abort', onAbort, { once: true });
    }

    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');

    child.stdout.on('data', (chunk) => {
      stdoutChunks.push(chunk);
      stdoutBuffer += chunk;
      const lines = stdoutBuffer.split(/\r?\n/);
      stdoutBuffer = lines.pop() || '';
      for (const line of lines) {
        if (opts.onStdout) opts.onStdout(line);
      }
    });

    child.stderr.on('data', (chunk) => {
      stderrAll += chunk;
      stderrBuffer += chunk;
      const lines = stderrBuffer.split(/\r?\n/);
      stderrBuffer = lines.pop() || '';
      for (const line of lines) {
        if (opts.onStderr) opts.onStderr(line);
      }
    });

    child.on('error', (err) => {
      if (opts.signal) opts.signal.removeEventListener('abort', onAbort);
      reject(err);
    });

    child.on('close', (code) => {
      if (opts.signal) opts.signal.removeEventListener('abort', onAbort);
      if (opts.stdoutBuffer && stdoutBuffer) {
        if (opts.onStdout) opts.onStdout(stdoutBuffer);
      }
      if (opts.stderrBuffer && stderrBuffer) {
        if (opts.onStderr) opts.onStderr(stderrBuffer);
      }
      resolve({
        code: code === null ? -1 : code,
        stdout: stdoutChunks.join(''),
        stderr: stderrAll,
      });
    });
  });
}

/**
 * استخراج معلومات الفيديو
 */
async function dumpJson(url, { cookiesFile, browser, playlist = false } = {}) {
  const args = [
    '--dump-single-json',
    '--no-colors',
    '--no-warnings',
    '--ignore-config',
    '--socket-timeout', '20',
    '--retries', '3',
    playlist ? '--yes-playlist' : '--no-playlist',
  ];

  if (cookiesFile && fs.existsSync(cookiesFile)) args.push('--cookies', cookiesFile);
  if (browser) args.push('--cookies-from-browser', browser);

  args.push(url);

  const res = await run(args, { timeout: 120000 });
  if (res.code !== 0) {
    // yt-dlp قد يكتب رسالة الخطأ على stdout أو stderr حسب نوعه
    const blob = `${res.stderr}\n${res.stdout.slice(-3000)}`;
    throw new Error(cleanError(blob) || 'تعذّر جلب معلومات الفيديو');
  }

  const raw = res.stdout.trim();
  if (!raw || raw === 'null' || raw === '{}') {
    throw new Error(cleanError(res.stdout) || 'تعذّر جلب معلومات الفيديو');
  }
  try {
    return JSON.parse(raw);
  } catch (_) {
    throw new Error('تعذّر قراءة بيانات الفيديو من الخادم');
  }
}

/**
 * تحويل رسائل خطأ yt-dlp إلى نص عربي مفهوم
 */
function cleanError(stderr) {
  if (!stderr) return '';
  const lines = stderr
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith('['))
    .filter((l) => !/^\d{4}-\d{2}-\d{2}/.test(l));

  const raw = lines.join(' ') || stderr.trim();
  const map = [
    [/unavailable/i, 'الفيديو غير متاح أو تم حذفه — تأكد من صحة الرابط'],
    [/private video/i, 'الفيديو خاص — جرّب تسجيل الدخول عبر الكوكيز'],
    [/members[- ]only/i, 'هذا المحتوى للمشتركين فقط — سجّل الدخول أو ارفع الكوكيز'],
    [/age[- ]?restricted|confirm your age/i, 'المحتوى محجوب بالعمر — سجّل الدخول عبر الكوكيز'],
    [/Video unavailable/i, 'الفيديو غير متاح'],
    [/Sign in to confirm|login required|cookies/i, 'مطلوب تسجيل الدخول — ارفع ملف الكوكيز أو اختر متصفحك'],
    [/Unsupported URL/i, 'الرابط غير مدعوم من المنصة'],
    [/HTTP Error 404/i, 'المحتوى غير موجود (404)'],
    [/HTTP Error 403/i, 'تم رفض الطلب (403) — قد تحتاج تسجيل الدخول'],
    [/Unable to download webpage|Connection refused|URLError|Network is unreachable/i, 'تعذّر الاتصال بالمنصة — تحقق من الإنترنت'],
    [/ffmpeg is not installed|ffmpeg not found|Failed to load ffmpeg/i, 'ffmpeg غير مثبت — شغّل: npm run setup'],
    [/Requested format is not available/i, 'الجودة المطلوبة غير متاحة لهذا الفيديو'],
    [/Requested format is not available|is not available/i, 'الجودة المطلوبة غير متاحة'],
  ];

  for (const [re, msg] of map) {
    if (re.test(raw)) return msg;
  }
  return raw.slice(0, 400);
}

module.exports = {
  init,
  isReady,
  run,
  dumpJson,
  cleanError,
  PROGRESS_PREFIX,
  PROGRESS_TEMPLATE,
  get version() { return VERSION; },
  get runner() { return RUNNER ? RUNNER.label : null; },
};
